package com.niit.Controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HandlingController {

	public HandlingController() {
		System.out.println("welcome..");
		// TODO Auto-generated constructor stub
	}
	
	@RequestMapping("/")
	public String gotohome()
	{
		return "home";
	}
	
	@RequestMapping("home")
	public String gotohme()
	{
		return "home";
	}
	
	@RequestMapping("aboutus")
	public String gotoaboutus()
	{
		return "aboutus";
	}
	
	@RequestMapping("mens")
	public String gotocheckin()
	{
		return "mens";
	}
	
	@RequestMapping("womens")
	public String gotochecki()
	{
		return "womens";
	}
	
	@RequestMapping("travels")
	public String gotocheck()
	{
		return "womens";
	}
	
	@RequestMapping("Login")
	public String gotoLogoi()
	{
		return "Login";
	}
	
	@RequestMapping("categories")
	public String gotocategories()
	{
		return "categories";
	}
	
	@RequestMapping("Register")
	public String gotoRegister()
	{
		return "Register";
	}
	
	
	@RequestMapping(value="/checklogin",method=RequestMethod.POST)
	public String validdateLogin(HttpServletRequest req) {
		String u=req.getParameter("username");
		String pass=req.getParameter("password");
		if ((u.equals("selva")) && (pass.equals("ganesh"))) {
			return "inside";
		}else{return"sorry";
		}
		}
	}

